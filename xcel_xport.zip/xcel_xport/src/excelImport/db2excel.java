package excelImport;

import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import DBUtil.DBUtil;

public class db2excel {
	
	public String xcelimport() {
	Connection con = DBUtil.getConnectivity();
	Statement stmt;
	ResultSet rs;
	try{
		String filename="updateddata1.xls";
		HSSFWorkbook hwb=new HSSFWorkbook();
		HSSFSheet sheet =  hwb.createSheet("new sheet");

  		HSSFRow rowhead=   sheet.createRow((short)0);
  		rowhead.createCell((short) 0).setCellValue("CourseID");
  		rowhead.createCell((short) 1).setCellValue("CourseName");
  		rowhead.createCell((short) 2).setCellValue("Days");
  		rowhead.createCell((short) 3).setCellValue("Reference");
  		rowhead.createCell((short) 4).setCellValue("Location");
  		stmt=con.createStatement();
  		rs=stmt.executeQuery("Select * from demo_table");
  		int i=1;
  		while(rs.next()){
  			HSSFRow row=   sheet.createRow((short)i);
  			row.createCell((short) 0).setCellValue(Integer.toString(rs.getInt("CourseID")));
  			row.createCell((short) 1).setCellValue(rs.getString("CourseName"));
  			row.createCell((short) 2).setCellValue(Integer.toString(rs.getInt("Days")));
  			row.createCell((short) 3).setCellValue(rs.getString("Reference"));
  			row.createCell((short) 4).setCellValue(rs.getString("Location"));
  			i++;
  		}
  		FileOutputStream fileOut =  new FileOutputStream(filename);
  		hwb.write(fileOut);
  		fileOut.close();
  		return "Your excel file has been generated!";
  		
  	} catch ( Exception ex ) {
  		System.out.println(ex);

  	}
	return null;
	}
}
