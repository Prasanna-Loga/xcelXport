package editTable;

import java.sql.Connection;
import java.sql.Statement;

import DBUtil.DBUtil;

public class editChange {

	public static void locationSet(String course,String loc) {
		Connection con = DBUtil.getConnectivity();
		Statement stmt;
		try
		{
			
			stmt = con.createStatement();
			 //System.out.println("Creating statement...");
			String query="UPDATE demo_table SET location = '"+loc+"' WHERE CourseName = '"+course+"'";
			stmt.executeQuery(query);
			
			System.out.println("Table changed for "+course+"..!");
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void change() {
		Connection con = DBUtil.getConnectivity();
		Statement stmt;
		try
		{
			
			stmt = con.createStatement();
			 System.out.println("Creating statement...");
			String query="Alter table demo_table Add Location varchar(20)";
			stmt.executeUpdate(query);
			
			System.out.println("Table changed in database..!");
			
			locationSet("C PROGRAMMING","Chennai");
			locationSet("CPP","Bangalore");
			locationSet("JAVA","Hyderabad");
			locationSet("PYTHON","Kochi");
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}
