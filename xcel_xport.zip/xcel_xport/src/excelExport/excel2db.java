package excelExport;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import DBUtil.DBUtil;

public class excel2db {

	public void xcelexport() {
	
	Connection con = DBUtil.getConnectivity();
	Statement stmt;
	ResultSet rs;
   	Queue<String> q = new LinkedList<>();
	
	try
	{
		
		stmt = con.createStatement();
		 //System.out.println("Creating statement...");
		String query="create table demo_table(CourseID int,CourseName varchar(20),Days int,Reference varchar(20))";
		rs = stmt.executeQuery(query);
		
		System.out.println("Table created in database..!");
		FileInputStream file = new FileInputStream(new File("data1.xls"));

		//Create Workbook instance holding reference to .xlsx file
		HSSFWorkbook workbook = new HSSFWorkbook(file);

		//Get first/desired sheet from the workbook
		HSSFSheet sheet = workbook.getSheetAt(0);

		//Iterate through each rows one by one
		Iterator<Row> rowIterator = sheet.iterator();
		rowIterator.next();
		while (rowIterator.hasNext()) 
		{
			//int i=0;
			Row row = rowIterator.next();
			//For each row, iterate through all the columns
			Iterator<Cell> cellIterator = row.cellIterator();
			
			while (cellIterator.hasNext()) 
			{
				Cell cell = cellIterator.next();
				//Check the cell type and format accordingly
				switch (cell.getCellType()) 
				{
					case Cell.CELL_TYPE_NUMERIC:
						//System.out.print(cell.getNumericCellValue() + "\t");
						//if(i==0)
							q.add(""+(int)(cell.getNumericCellValue()));
						break;
					case Cell.CELL_TYPE_STRING:
						//System.out.print(cell.getStringCellValue() + "\t");
						q.add(cell.getStringCellValue());
						break;
				}
			}
				
				stmt = con.createStatement();
				 
				PreparedStatement ps=con.prepareStatement("insert into demo_table values (?,?,?,?)");
				ps.setInt(1,Integer.parseInt(q.peek()));
				System.out.println(q.peek());
				q.remove();
				ps.setString(2,q.peek());
				System.out.println(q.peek());
				q.remove();
				ps.setInt(3,Integer.parseInt(q.peek()));
				System.out.println(q.peek());
				q.remove();
				ps.setString(4,q.peek());
				System.out.println(q.peek());
				q.remove();
				int rs1=ps.executeUpdate();  
				System.out.println(rs1+" records affected");
				if(rs1>0)
				System.out.println("Registration Successful");
			
			//System.out.println("");
		}
		file.close();
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	}
}
}
	
	
	
	
	

