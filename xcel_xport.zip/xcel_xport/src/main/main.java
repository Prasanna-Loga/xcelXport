package main;

import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import DBUtil.DBUtil;
import editTable.editChange;
import excelExport.excel2db;
import excelImport.db2excel;  

public class main{
	
    public static void main(String[]args){
    	excel2db export=new excel2db();
		db2excel import1=new db2excel();
		editChange change=new editChange();
		
		export.xcelexport();
		
		change.change();
		
		System.out.println(import1.xcelimport());
    	
	
    }
}